
export default function Cat(){
    return <h2>Meaww</h2>
}