import { Link, Route, Routes } from "react-router-dom"
import Cat from "./Cat"
import Dog from "./Dog"

export default function PageNotFound(){
    return(
        <div>
            <h1>Page Not Found </h1>
            <h3> you can go to home Page:  <Link to='/'>Home</Link> </h3>

        <div>
        <Link to='/cat'>Cat</Link> &nbsp;
        <Link to='/dog'>Dog</Link> 
        </div>

            <Routes>
            <Route path='/cat' element={<Cat />} />
            <Route path='/dog' element={<Dog />} />
            </Routes>

            

        </div>
    )
}