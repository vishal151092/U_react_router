
export default function User(){
    return <h1> User Page Screen</h1>
}