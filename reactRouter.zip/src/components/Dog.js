
export default function Dog(){
    return <h2>Woff Woff</h2>
}