
import './App.css';
import {React} from 'react';
import Home from './components/Home';
import About from './components/About';
import User from './components/User';
import PageNotFound from './components/PageNotFound';
import {Route, Routes, Link} from 'react-router-dom';

function App() {


  return (
    <>
      <h2>Test-app 2</h2>

    {/* Old Way: <a href='/User'>User</a> <br /><br /> */}

    {/* New Way: <Link to='/User'>User</Link> */}

    <Link to='/'>Home</Link> &nbsp;
    <Link to='/User'>User</Link> &nbsp;
    <Link to='/About'>About</Link>

    <div>
        <Link to='/cat'>Cat</Link> &nbsp;
        <Link to='/dog'>Dog</Link> 
        </div>
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/User' element={<User />} />
      <Route path='/About' element={<About />} />
      <Route path='*' element={<PageNotFound />} />
    </Routes>



      {/* <Home />
      <About />
      <User /> */}
    </>
    
  );
}

export default App;
